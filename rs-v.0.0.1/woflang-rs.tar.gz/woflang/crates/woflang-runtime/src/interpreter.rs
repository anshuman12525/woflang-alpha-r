//! Core interpreter for the Woflang stack machine.
//!
//! The [`Interpreter`] executes Woflang source code by tokenizing input
//! and dispatching operations through the registry. It maintains the
//! execution state (stack) and provides the context for operation handlers.

use crate::{Registry, Token, TokenKind, Tokenizer};
use std::fs;
use std::io::{self, BufRead, Write};
use std::path::Path;
use woflang_core::{InterpreterContext, Result, WofError, WofStack, WofValue};

/// The Woflang interpreter.
///
/// Manages the execution state and operation dispatch for a Woflang
/// program. The interpreter owns both the stack and the operation
/// registry, providing a complete execution environment.
///
/// # Examples
///
/// ```
/// use woflang_runtime::Interpreter;
///
/// let mut interp = Interpreter::new();
/// interp.exec_line("42 17 +").unwrap();
///
/// let result = interp.stack().peek().unwrap().as_integer().unwrap();
/// assert_eq!(result, 59);
/// ```
pub struct Interpreter {
    stack: WofStack,
    registry: Registry<Self>,
    /// Debug mode: print stack after each line.
    pub debug: bool,
}

impl Default for Interpreter {
    fn default() -> Self {
        Self::new()
    }
}

impl Interpreter {
    /// Create a new interpreter with an empty registry.
    #[must_use]
    pub fn new() -> Self {
        Self {
            stack: WofStack::with_capacity(64),
            registry: Registry::new(),
            debug: false,
        }
    }

    /// Create an interpreter with a pre-configured registry.
    #[must_use]
    pub fn with_registry(registry: Registry<Self>) -> Self {
        Self {
            stack: WofStack::with_capacity(64),
            registry,
            debug: false,
        }
    }

    /// Get a reference to the registry.
    #[must_use]
    pub fn registry(&self) -> &Registry<Self> {
        &self.registry
    }

    /// Get a mutable reference to the registry.
    #[must_use]
    pub fn registry_mut(&mut self) -> &mut Registry<Self> {
        &mut self.registry
    }

    /// Register an operation handler.
    pub fn register<F>(&mut self, name: impl Into<String>, handler: F)
    where
        F: Fn(&mut Self) -> Result<()> + Send + Sync + 'static,
    {
        self.registry.register(name, handler);
    }

    // ═══════════════════════════════════════════════════════════════
    // EXECUTION
    // ═══════════════════════════════════════════════════════════════

    /// Execute a single line of Woflang code.
    ///
    /// The line is tokenized and each token is dispatched through the
    /// interpreter. Errors are returned immediately; partial execution
    /// may have modified the stack.
    pub fn exec_line(&mut self, line: &str) -> Result<()> {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            return Ok(());
        }

        let tokenizer = Tokenizer::new(trimmed);
        for token in tokenizer {
            self.dispatch_token(&token)?;
        }

        if self.debug {
            eprintln!("[debug] {}", self.stack);
        }

        Ok(())
    }

    /// Execute a script from a file.
    pub fn exec_file(&mut self, path: impl AsRef<Path>) -> Result<()> {
        let content = fs::read_to_string(path.as_ref()).map_err(WofError::from)?;
        for line in content.lines() {
            self.exec_line(line)?;
        }
        Ok(())
    }

    /// Run an interactive REPL (Read-Eval-Print Loop).
    ///
    /// Reads lines from stdin and executes them. Errors are printed
    /// but do not terminate the REPL.
    pub fn repl(&mut self) -> io::Result<()> {
        let stdin = io::stdin();
        let mut stdout = io::stdout();

        writeln!(stdout, "Woflang REPL v{}. Type 'exit' to quit.", woflang_core::VERSION)?;

        let reader = stdin.lock();
        for line in reader.lines() {
            let line = line?;
            let trimmed = line.trim();

            if trimmed == "exit" || trimmed == "quit" {
                writeln!(stdout, "Goodbye from woflang! 🐺")?;
                break;
            }

            if trimmed == ".s" || trimmed == "." {
                writeln!(stdout, "{}", self.stack)?;
                continue;
            }

            match self.exec_line(&line) {
                Ok(()) => {
                    if !self.stack.is_empty() {
                        if let Ok(top) = self.stack.peek() {
                            writeln!(stdout, "→ {top}")?;
                        }
                    }
                }
                Err(e) => {
                    writeln!(stdout, "Error: {e}")?;
                }
            }
        }

        Ok(())
    }

    /// Dispatch a single token.
    fn dispatch_token(&mut self, token: &Token<'_>) -> Result<()> {
        match token.kind {
            TokenKind::Integer => {
                let value: i64 = token.text.parse()?;
                self.stack.push(WofValue::integer(value));
            }
            TokenKind::Float => {
                let value: f64 = token.text.parse()?;
                self.stack.push(WofValue::double(value));
            }
            TokenKind::String => {
                let value = crate::tokenizer::parse_string_literal(token.text);
                self.stack.push(WofValue::string(value));
            }
            TokenKind::Symbol => {
                self.dispatch_symbol(token.text)?;
            }
            TokenKind::Eof => {}
        }
        Ok(())
    }

    /// Dispatch a symbol (operation or identifier).
    fn dispatch_symbol(&mut self, name: &str) -> Result<()> {
        // Look up in registry
        if let Some(op) = self.registry.get(name) {
            // Clone the boxed op to avoid borrow conflict
            // This is necessary because ops can modify self
            let op = op as *const _;
            // SAFETY: We're calling the op immediately and not storing the pointer
            // The registry lifetime exceeds this call
            return unsafe { (*op)(self) };
        }

        // Not found: push as symbol
        self.stack.push(WofValue::symbol(name));
        Ok(())
    }
}

// ═══════════════════════════════════════════════════════════════════════
// InterpreterContext IMPLEMENTATION
// ═══════════════════════════════════════════════════════════════════════

impl InterpreterContext for Interpreter {
    #[inline]
    fn push(&mut self, value: WofValue) {
        self.stack.push(value);
    }

    #[inline]
    fn pop(&mut self) -> Result<WofValue> {
        self.stack.pop()
    }

    #[inline]
    fn peek(&self) -> Result<&WofValue> {
        self.stack.peek()
    }

    #[inline]
    fn has(&self, n: usize) -> bool {
        self.stack.has(n)
    }

    #[inline]
    fn stack(&self) -> &WofStack {
        &self.stack
    }

    #[inline]
    fn stack_mut(&mut self) -> &mut WofStack {
        &mut self.stack
    }

    #[inline]
    fn clear(&mut self) {
        self.stack.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_interp() -> Interpreter {
        let mut interp = Interpreter::new();

        // Register basic ops for testing
        interp.register("+", |ctx| {
            let b = ctx.stack_mut().pop_numeric()?;
            let a = ctx.stack_mut().pop_numeric()?;
            ctx.push(WofValue::double(a + b));
            Ok(())
        });

        interp.register("-", |ctx| {
            let b = ctx.stack_mut().pop_numeric()?;
            let a = ctx.stack_mut().pop_numeric()?;
            ctx.push(WofValue::double(a - b));
            Ok(())
        });

        interp.register("dup", |ctx| ctx.stack_mut().dup());
        interp.register("drop", |ctx| ctx.stack_mut().drop());
        interp.register("swap", |ctx| ctx.stack_mut().swap());

        interp
    }

    #[test]
    fn exec_arithmetic() {
        let mut interp = make_interp();
        interp.exec_line("5 3 +").unwrap();

        let result = interp.stack.pop_numeric().unwrap();
        assert!((result - 8.0).abs() < f64::EPSILON);
    }

    #[test]
    fn exec_stack_ops() {
        let mut interp = make_interp();
        interp.exec_line("42 dup").unwrap();

        assert_eq!(interp.stack.len(), 2);
        assert_eq!(interp.stack.pop_integer().unwrap(), 42);
        assert_eq!(interp.stack.pop_integer().unwrap(), 42);
    }

    #[test]
    fn exec_swap() {
        let mut interp = make_interp();
        interp.exec_line("1 2 swap").unwrap();

        assert_eq!(interp.stack.pop_integer().unwrap(), 1);
        assert_eq!(interp.stack.pop_integer().unwrap(), 2);
    }

    #[test]
    fn unknown_symbol_pushed() {
        let mut interp = make_interp();
        interp.exec_line("undefined_op").unwrap();

        let val = interp.stack.pop().unwrap();
        assert_eq!(val.as_str().unwrap(), "undefined_op");
    }

    #[test]
    fn parse_string_literal() {
        let mut interp = make_interp();
        interp.exec_line(r#""hello world""#).unwrap();

        let val = interp.stack.pop().unwrap();
        assert_eq!(val.as_str().unwrap(), "hello world");
    }

    #[test]
    fn empty_line_noop() {
        let mut interp = make_interp();
        interp.exec_line("").unwrap();
        interp.exec_line("   ").unwrap();

        assert!(interp.stack.is_empty());
    }
}
